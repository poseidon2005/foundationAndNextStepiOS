//
//  DataService.swift
//  devslopes-showcase
//
//  Created by Mark Price on 8/24/15.
//  Copyright © 2015 devslopes. All rights reserved.
//

import Foundation
import Firebase

class DataService {
    static let ds = DataService()
    
    private var _REF_BASE = Firebase(url: "https://devslopes-showcase.firebaseio.com")
    
    var REF_BASE: Firebase {
        return _REF_BASE
    }
}