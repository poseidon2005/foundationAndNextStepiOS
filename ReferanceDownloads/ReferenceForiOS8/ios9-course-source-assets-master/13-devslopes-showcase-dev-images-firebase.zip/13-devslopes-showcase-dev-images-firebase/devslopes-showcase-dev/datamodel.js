{
    posts: {
        ak32kacq: {
            description: "This is my app",
            imageUrl: "http://imageshack.com/2334..",
            likes: 200
        },
        ui91llqq: {
            description: "I built this in 3 hours",
            imageUrl: "http://imageshack.com/ad32..",
            likes: 124
        }
    }
    
    users: {
        j234jl2c: {
            username: "jdawg500"
            posts: {
                ak32kacq: true,
                bck20app: true
            },
            likes: {
                zi23katy: true,
                ui91llqq: true
            }
        }
    }
}